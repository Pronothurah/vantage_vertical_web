export { default as Navbar } from './navbar/Navbar';
export { default as Brand } from './brand/Brand';
export { default as About } from './about/About';
export { default as Home } from './home/Home';
export { default as Technology } from './technology/Technology';
export { default as FormValidation } from './formvalidation/FormValidation';
export { default as Training } from './training/Training';
export { default as Portfolio } from './portfolio/Portfolio';
export { default as ScrollToTop } from './scroll/ScrollToTop';

