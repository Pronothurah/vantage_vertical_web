import React from 'react';

import './blog.css';

const Blog = () => {
    return(
        <>
        <div className='vantage__blog'>
            <div className="vantage__blog-heading section__padding gradient__bg">  
                    <h1>BLOG</h1>
                    <p>MEDIA | NEWS | ANNOUNCEMENTS</p>        
            </div>
        </div>
        </>
    );
};


export default Blog;
